
import './App.css'
import Home from './Pages/Home'

// Action,--> reducer-->store

function App() {

  return (
    <>
  <Home/>
    </>
  )
}

export default App

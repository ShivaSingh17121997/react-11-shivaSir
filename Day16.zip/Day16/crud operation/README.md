// create form compoent send data to the json server / backend

// get the data form api shown into the ui 

CRUD create and read is done;
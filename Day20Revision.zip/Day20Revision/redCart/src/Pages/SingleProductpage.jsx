import React from 'react'

export default function SingleProductpage() {
  return (
    <div>SingleProductpage</div>
  )
}

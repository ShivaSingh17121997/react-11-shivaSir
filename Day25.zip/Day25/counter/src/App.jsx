import './App.css'
import Counter from './Pages/Counter'
import Todo from './Pages/Todo'

function App() {

  return (
    <>
      {/* <Counter /> */}
      <Todo />
    </>
  )
}

export default App

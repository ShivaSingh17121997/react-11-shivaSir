


//counter
export const INCREMENT = "INCREMENT"
export const DECREMENT = "DECREMENT"
export const RESET = "RESET"



// todo

export const ADD_TODO_DATA = "ADD_TODO_DATA";
export const GET_TODO_DATA = "GET_TODO_DATA";
export const DELETE_TODO_DATA = "DELETE_TODO_DATA";
export const UPDATE_TODO_DATA = "UPDATE_TODO_DATA";


// product

export const SORTBYASC = "SORTBYASC";
export const SORTBYDESC = "SORTBYDESC";
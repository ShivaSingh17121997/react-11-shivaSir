import React, { useState } from 'react'
import { db } from '../Firebase';
import { collection, addDoc } from "firebase/firestore";

export default function Home() {
    const [todo, setTodo] = useState('');
    const todoCollection = collection(db, "todos");

    const handleForm = async (e) => {
        e.preventDefault();
        await addDoc(todoCollection, { todo: todo });
        setTodo('');
        console.log(addDoc)
        console.log("Data addes successfully")
    }

    return (
        <div>

            <form onSubmit={handleForm} >
                <input value={todo} onChange={(e) => setTodo(e.target.value)} type="text" placeholder='Add your todo...' />
                <button >Add todo</button>
            </form>
        </div>
    )
}

import React from 'react'

export default function Signup() {
    return (
        <div>
            <input type="text" /> <br /><br />
            <input type="text" /><br /><br />
            <button>Signup</button>
        </div>
    )
}

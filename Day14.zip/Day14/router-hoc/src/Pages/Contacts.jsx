import React from 'react'

export default function Contacts() {
  return (
    <div>
        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Saepe quidem vel id molestias illo ad maxime inventore vitae at tempora minima, optio exercitationem natus nisi aspernatur. Quaerat praesentium nostrum tempora.</p>

        <h5>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Placeat adipisci ut alias dicta, perferendis amet cupiditate quibusdam earum nostrum consectetur quasi deserunt. Sit quos est exercitationem accusantium deleniti aliquid id.</h5>
    </div>
  )
}

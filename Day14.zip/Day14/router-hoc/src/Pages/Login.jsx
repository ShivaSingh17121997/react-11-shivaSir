import React from 'react'

export default function Login() {
  return (
    <div>
        <input type="text" /> <br/><br/>
        <input type="text" /><br/><br/>
        <button>Login</button>
    </div>
  )
}

import React from 'react'

export default function SingleProductPage() {
    return (
        <div>
            <img width="80%" src="https://imgv3.fotor.com/images/slider-image/A-clear-close-up-photo-of-a-woman.jpg" alt="kuch to gadbad hai" />
        </div>
    )
}

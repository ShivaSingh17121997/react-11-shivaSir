



step-1 instal react-router-dom

step-2 create all routes page

step-3 wrap the app compoent with browserrouter component

step-4 created Navbar provide link to it

step-5 imported navbar and allroutes in app.jsx


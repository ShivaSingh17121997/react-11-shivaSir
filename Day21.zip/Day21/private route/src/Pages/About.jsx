import React from 'react'

export default function About() {
    return (
        <div>
            <h1>about</h1>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ut eveniet corporis error temporibus. Deleniti odio, quae totam autem provident voluptatum iure accusantium at sed in sapiente ex soluta architecto minus, sit harum saepe beatae libero incidunt mollitia neque esse rerum. Delectus velit quis fugiat facere vel! Pariatur, mollitia dolorem? Nobis, ex eaque esse, consectetur nostrum accusantium ipsam repudiandae perspiciatis illo ratione quod earum voluptate asperiores eligendi modi! Esse cumque omnis odit iste repellat ea nesciunt sint repudiandae! Adipisci illum officia nisi, amet aliquid autem culpa saepe necessitatibus labore. Quo sunt, magnam dolorum aut minima corrupti omnis laborum repellat sit saepe modi necessitatibus aspernatur hic ducimus dicta ullam optio aliquid ab iure. Totam sit veritatis aliquid repellat praesentium distinctio dignissimos provident, consequuntur assumenda natus placeat saepe inventore? Veritatis fugit quo temporibus adipisci dicta. Dolore alias iure rem, adipisci nostrum magni praesentium amet libero aliquid. Dolorem aspernatur excepturi soluta. Officiis voluptatem modi, recusandae officia facere molestiae delectus! Iure excepturi neque, ab similique commodi molestiae reiciendis laborum ipsum adipisci perspiciatis, consequatur aperiam mollitia veritatis architecto unde minima consequuntur obcaecati magni nisi placeat quaerat, voluptatum deserunt? Veniam dolore sed totam eveniet quia vero beatae porro mollitia nulla cupiditate, ratione quis doloribus doloremque accusamus eaque!</p>
        </div>
    )
}

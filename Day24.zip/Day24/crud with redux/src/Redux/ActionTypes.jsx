



export const ADDTODODATA = "ADDTODODATA";

export const EDITTODODATA = "EDITTODODATA";

export const DELETETODODATA = "DELETETODODATA";

export const GETTODODATA = "GETTODODATA";

export const TOKEN = "TOKEN";
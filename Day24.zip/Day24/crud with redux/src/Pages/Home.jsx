import React, { useState } from 'react'
import { useDispatch } from 'react-redux';
import { ADDTODODATA } from '../Redux/ActionTypes';

export default function Home() {
    const [todo, setTodo] = useState("");
    const dispatch = useDispatch();

    const handleAddTask = () => {
        dispatch({ type: ADDTODODATA, payload: todo })
    }

    return (
        <div>
            <h1>Todo app with redux</h1>
            <input value={todo} onChange={(e) => setTodo(e.target.value)} type="text" placeholder='Add task' />
            <button onClick={handleAddTask} > Add</button>
        </div>
    )
}

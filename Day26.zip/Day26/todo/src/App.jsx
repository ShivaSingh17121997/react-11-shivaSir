
import './App.css'
import Home from './Page/Home'
import Login from './Page/Login'
import Signup from './Page/Signup'

function App() {

  return (
    <>
      {/* <Home /> */}
      <Signup />
      <Login />
    </>
  )
}

export default App
